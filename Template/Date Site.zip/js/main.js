


$(".menu-toggle").click(function(){
$(".warrap").toggleClass("innerpage");
}); 
